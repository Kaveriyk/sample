package com.nagarro.training.advancejava.Assignment5App1.ServiceImpl;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.training.advancejava.Assignment5App1.Model.User;
import com.nagarro.training.advancejava.Assignment5App1.Service.userService;

@Service
public class userServiceImpl implements userService {

	/*
	 * to check the credentials
	 * 
	 * @param user login
	 * 
	 * @return boolean
	 */
	@Override
	public boolean isLoggedIn(User login) {
		String uname = login.getUsername();
		String pass = login.getPassword();
		String uri = "http://localhost:8081/login/" + uname;
		RestTemplate restTemplate = new RestTemplate();
		User user = restTemplate.getForObject(uri, User.class);
		System.out.print(user);
		if (user.getUsername() != null && user.getUsername().equalsIgnoreCase(uname)
				&& user.getPassword().equalsIgnoreCase(pass)) {
			return true;
		} else
			return false;
	}

}
