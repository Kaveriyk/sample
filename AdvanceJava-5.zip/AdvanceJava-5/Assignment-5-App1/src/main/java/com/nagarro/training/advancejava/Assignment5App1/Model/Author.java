package com.nagarro.training.advancejava.Assignment5App1.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Author {

	@Override
	public String toString() {
		return authorName;
	}

	@Id
	String authorName;

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

}
