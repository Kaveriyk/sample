package com.nagarro.training.advancejava.Assignment5App1.Validations;

import org.springframework.ui.Model;

public class inputValidation {

	/**
	 * check if book code is valid
	 * 
	 * @param bookCode
	 * @param model
	 * @return boolean
	 */
	public static boolean isBookCodeValid(String bookCode, Model model) {
		bookCode = bookCode.trim();
		if ("0".equals(bookCode) || "null".equalsIgnoreCase(bookCode)) {
			model.addAttribute("bookCodeError", "Invalid BookCode");
			return false;
		}
		return true;
	}

}
