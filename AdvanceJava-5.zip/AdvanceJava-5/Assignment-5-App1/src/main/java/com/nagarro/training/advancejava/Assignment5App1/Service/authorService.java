package com.nagarro.training.advancejava.Assignment5App1.Service;

import java.util.List;

import com.nagarro.training.advancejava.Assignment5App1.Model.Author;

public interface authorService {

	/**
	 * to find all the authors in db
	 * 
	 * @return List of author
	 */
	public List<Author> findAll();
}
