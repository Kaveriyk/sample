package com.nagarro.training.advancejava.Assignment5App1.Controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nagarro.training.advancejava.Assignment5App1.Model.Author;
import com.nagarro.training.advancejava.Assignment5App1.Model.Book;
import com.nagarro.training.advancejava.Assignment5App1.Service.authorService;
import com.nagarro.training.advancejava.Assignment5App1.Service.bookService;
import com.nagarro.training.advancejava.Assignment5App1.Validations.inputValidation;

@Controller
@RequestMapping("/books/")
public class bookController {

	private List<Author> authors;
	@Autowired
	private bookService bukService;
	@Autowired
	private authorService authorrService;

	/*
	 * to show the add book html page or form
	 *
	 * @param Book object for next form
	 *
	 * @return String
	 */
	@GetMapping("")
	public String showAddBookForm(Book book, Model model) {
		model.addAttribute("standardDate", new Date());
		authors = authorrService.findAll();
		model.addAttribute("authors", authors);
		return "addBook";
	}

	/*
	 * to show update form
	 * 
	 * @param model
	 * 
	 * @return string
	 * 
	 */
	@GetMapping("list")
	public String showBooks(Model model) {
		List<Book> books = bukService.findAll();
		if (books.isEmpty()) {
			model.addAttribute("listEmpty", "No Book Added");
			return "book";
		}
		model.addAttribute("books", bukService.findAll());

		return "book";
	}

	/*
	 * to add book to db
	 * 
	 * @param1 Book to be added
	 * 
	 * @param2 BindingResult
	 * 
	 * @param3 MultipartFile file
	 * 
	 * @param4 model
	 *
	 * @return string
	 */
	@PostMapping("")
	public String addBook(@Valid Book book, BindingResult result, Model model) {
		// System.out.print(book);
		if (result.hasErrors() || !inputValidation.isBookCodeValid(book.getBookCode(), model)) {
			model.addAttribute("standardDate", new Date());
			model.addAttribute("authors", authors);
			return "addBook";
		}
		if (bukService.findBook(book.getBookCode()) == null) {
			book.setDateAdded(DateFormat.getDateInstance().format(new Date()));
			if (bukService.save(book)) {
				return "redirect:list";
			}
		} else {
			model.addAttribute("bookCodeError", "Book with same code exists");
		}
		model.addAttribute("standardDate", new Date());
		model.addAttribute("authors", authors);
		return "addBook";
	}

	/*
	 * to show the update book form
	 * 
	 * @param1 int id
	 * 
	 * @param2 model
	 * 
	 * @return string
	 */
	@GetMapping("{id}")
	public String showUpdateForm(@PathVariable("id") String id, Model model) {
		try {
			Book book = bukService.findBook(id);
			model.addAttribute("book", book);
			authors = authorrService.findAll();
			model.addAttribute("authors", authors);
			return "updateBook";
		} catch (IllegalArgumentException e) {
			model.addAttribute("error", "Invalid Book");
			return "book";
		}
	}

	/*
	 * to update book in db
	 * 
	 * @param1 int id
	 * 
	 * @param2 MultipartFile file
	 * 
	 * @param3 Book to be added
	 * 
	 * @param4 BindingResult
	 * 
	 * @param5 model
	 * 
	 * @return String
	 */
	@PostMapping("update/{id}")
	public String updateBook(@PathVariable("id") String id, @Valid Book book, BindingResult result, Model model) {
		if (result.hasErrors()) {
			book.setBookCode(id);
			model.addAttribute("authors", authors);
			return "updateBook";
		}
		model.addAttribute("books", bukService.updateBook(book, id));
		return "book";
	}

	/*
	 * to delete the book from db
	 * 
	 * @param1 int id
	 * 
	 * @param2 model
	 * 
	 * @return string
	 */
	@GetMapping("delete/{id}")
	public String deleteBook(@PathVariable("id") String id, Model model) {
		try {
			model.addAttribute("books", bukService.delete(id));
			return "book";
		} catch (IllegalArgumentException e) {
			model.addAttribute("error", "Invalid Book");
			return "book";
		}

	}

}
