package com.nagarro.training.advancejava.Assignment5App1.ServiceImpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.training.advancejava.Assignment5App1.Model.Author;
import com.nagarro.training.advancejava.Assignment5App1.Service.authorService;

@Service
public class authorServiceImpl implements authorService {

	/**
	 * to find all the authors in db
	 * 
	 * @return List of author
	 */
	@Override
	public List<Author> findAll() {
		String uri = "http://localhost:8081/authors";
		RestTemplate restTemplate = new RestTemplate();
		Author[] authors = restTemplate.getForObject(uri, Author[].class);
		return Arrays.asList(authors);
	}

}
