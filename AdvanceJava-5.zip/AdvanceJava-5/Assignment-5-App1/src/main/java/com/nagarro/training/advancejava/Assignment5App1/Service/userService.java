package com.nagarro.training.advancejava.Assignment5App1.Service;

import com.nagarro.training.advancejava.Assignment5App1.Model.User;

public interface userService {

	/*
	 * to check the credentials
	 * 
	 * @param user login
	 * 
	 * @return boolean
	 */
	public boolean isLoggedIn(User login);

}
