package com.nagarro.training.advancejava.Assignment5App1.Service;

import java.util.List;

import com.nagarro.training.advancejava.Assignment5App1.Model.Book;

public interface bookService {

	/**
	 * to find all the books in db
	 * 
	 * @return List of book
	 */
	public List<Book> findAll();

	/**
	 * to save book in db
	 * 
	 * @param book
	 * 
	 * @return boolean
	 */
	public boolean save(Book book);

	/**
	 * to update book in db
	 * 
	 * @param1 book
	 * 
	 * @param2 MultipartFile file
	 * 
	 * @return List of book
	 */
	public List<Book> updateBook(Book book, String id);

	/**
	 * to delete book in db
	 * 
	 * @param long id
	 * 
	 * @return List of book
	 */
	public List<Book> delete(String id);

	/**
	 * @param String id
	 * @return book
	 */
	public Book findBook(String id);

}
