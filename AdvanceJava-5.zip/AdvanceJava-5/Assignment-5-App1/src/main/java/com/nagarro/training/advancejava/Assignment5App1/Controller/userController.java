package com.nagarro.training.advancejava.Assignment5App1.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nagarro.training.advancejava.Assignment5App1.Model.User;
import com.nagarro.training.advancejava.Assignment5App1.Service.userService;

@Controller
public class userController {

	@Autowired
	private userService userrService;

	/*
	 * to show the login page
	 */
	@GetMapping("/login")
	public String showLogin() {
		return "index";
	}

	/*
	 * to logout and redirect to login page
	 * 
	 * @return String
	 */
	@RequestMapping(value = "/logout")
	public String logoutPage() {
		return "redirect:/login?logout";
	}

	/*
	 * Check for Credentials
	 * 
	 * @param1 user
	 * 
	 * @param2 model
	 * 
	 * @return String
	 */
	@PostMapping("/login")
	public String login(@ModelAttribute(name = "loginForm") User login, Model m) {
		if (userrService.isLoggedIn(login)) {
			return "redirect:/books/list";
		} else {
			m.addAttribute("error", "Incorrect Username & Password");
			return "index";
		}
	}

}
