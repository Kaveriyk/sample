package com.nagarro.training.advancejava.Assignment5App1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment5App1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment5App1Application.class, args);
	}

}
