package com.nagarro.training.advancejava.Assignment5App1.ServiceImpl;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.training.advancejava.Assignment5App1.Model.Book;
import com.nagarro.training.advancejava.Assignment5App1.Service.bookService;

@Service
public class bookServiceImpl implements bookService {

	/**
	 * to find all the books in db
	 * 
	 * @return List of book
	 */
	@Override
	public List<Book> findAll() {
		String uri = "http://localhost:8081/books";
		RestTemplate restTemplate = new RestTemplate();
		Book[] books = restTemplate.getForObject(uri, Book[].class);
		return Arrays.asList(books);
	}

	/**
	 * to save book in db
	 * 
	 * @param book
	 * 
	 * @return boolean
	 */
	@Override
	public boolean save(Book book) {
		/*
		 * // TODO Auto-generated method stub
		 * //if(bookRepo.findById(book.getBookCode()).isEmpty()) { bookRepo.save(book);
		 * return true;
		 * 
		 * } return false;
		 */
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Book> entity = new HttpEntity<Book>(book, headers);
		RestTemplate restTemplate = new RestTemplate();
		/*
		 * String body = restTemplate.exchange("http://localhost:8081/books/add",
		 * HttpMethod.POST, entity, String.class) .getBody();
		 */
		HttpStatus b = restTemplate.exchange("http://localhost:8081/books/add", HttpMethod.POST, entity, String.class)
				.getStatusCode();
		System.out.print(b);
		return true;
	}

	/**
	 * to update book in db
	 * 
	 * @param1 book
	 * 
	 * @param2 MultipartFile file
	 * 
	 * @return List of book
	 */
	@Override
	public Book findBook(String id) {
		String uri = "http://localhost:8081/books/" + id;
		RestTemplate restTemplate = new RestTemplate();
		Book book = restTemplate.getForObject(uri, Book.class);
		return book;
	}

	/**
	 * to delete book in db
	 * 
	 * @param long id
	 * 
	 * @return List of book
	 */
	@Override
	public List<Book> updateBook(Book book, String id) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Book> entity = new HttpEntity<Book>(book, headers);
		RestTemplate restTemplate = new RestTemplate();
		String body = restTemplate.exchange("http://localhost:8081/books/" + id, HttpMethod.PUT, entity, String.class)
				.getBody();

//			HttpStatus b = restTemplate.exchange("http://localhost:8081/books/" + id, HttpMethod.PUT, entity, String.class)
//					.getStatusCode();
//			System.out.print(b);
		return findAll();
	}

	/**
	 * @param String id
	 * @return book
	 */
	@Override
	public List<Book> delete(String id) {
		// TODO Auto-generated method stub
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Book> entity = new HttpEntity<Book>(headers);
		RestTemplate restTemplate = new RestTemplate();
		System.out.print(id);
		int status = restTemplate.exchange("http://localhost:8081/books/" + id, HttpMethod.DELETE, entity, String.class)
				.getStatusCodeValue();
		/*
		 * HttpStatus b = restTemplate.exchange("http://localhost:8081/books/" + id,
		 * HttpMethod.DELETE, entity, String.class) .getStatusCode();
		 * System.out.print(b);
		 */
		if (status == 400) {
			throw new IllegalArgumentException();
		}
		return findAll();
	}

}
