package com.nagarro.training.advancejava.Assignment5App1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment5App1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
