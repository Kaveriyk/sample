package com.nagarro.training.advancejava.Assignment5App2.Controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.training.advancejava.Assignment5App2.Model.Book;
import com.nagarro.training.advancejava.Assignment5App2.Service.bookService;

@SuppressWarnings({ "rawtypes", "unchecked" })
@RestController
@RequestMapping("/books")
public class bookController {

	@Autowired
	private bookService bukService;

	/**
	 * to get all the authors
	 * 
	 * @return response entity
	 */
	@GetMapping()
	public ResponseEntity<?> all() {
		return new ResponseEntity(bukService.findAll(), HttpStatus.OK);
	}

	/**
	 * to add new book
	 * 
	 * @param newBook
	 * @return response entity
	 */
	@PostMapping("/add")
	public ResponseEntity<?> newbook(@RequestBody Book newBook) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("DATA", bukService.save(newBook));
		map.put("Message", "SUCCESSFULLY CREATED");
		return new ResponseEntity(map, HttpStatus.CREATED);
	}

	/**
	 * to update book
	 * 
	 * @param newBook
	 * @param id
	 * @return response entity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<?> updateBook(@RequestBody Book newBook, @PathVariable String id) {
		HashMap<String, Object> map = new HashMap<>();
		return bukService.findById(id).map(book -> {
			book.setBookName(newBook.getBookName());
			map.put("DATA", bukService.save(book));
			map.put("Message", "SUCCESSFULLY UPDATED");
			return new ResponseEntity(map, HttpStatus.OK);
		}).orElseGet(() -> {
			// newBook.setId(id);
			// map.put("DATA",bookService.save(newBook));
			map.put("Message", "No such ID Exists");
			return new ResponseEntity(map, HttpStatus.BAD_REQUEST);
		});
	}

	/**
	 * to delete book
	 * 
	 * @param id
	 * @return response entity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteBook(@PathVariable String id) {
		HashMap<String, Object> map = new HashMap<>();
		return bukService.findById(id).map(book -> {
			bukService.deleteById(id);
			map.put("Message", "SUCCESSFULLY DELETED");
			return new ResponseEntity(map, HttpStatus.OK);
		}).orElseGet(() -> {
			map.put("Message", "No such ID Exists");
			return new ResponseEntity(map, HttpStatus.BAD_REQUEST);
		});
	}

	/**
	 * to find by bar code
	 * 
	 * @param id
	 * @return response entity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<?> findbyId(@PathVariable String id) {
		return new ResponseEntity(bukService.findById(id), HttpStatus.OK);
	}

}
