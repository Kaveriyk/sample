package com.nagarro.training.advancejava.Assignment5App2.Service;

import java.util.List;
import java.util.Optional;

import com.nagarro.training.advancejava.Assignment5App2.Model.Book;

public interface bookService {

	/**
	 * to find all the books in db
	 * 
	 * @return List of book
	 */
	public List<Book> findAll();

	/**
	 * to save book in db
	 * 
	 * @param book
	 * 
	 * @return boolean
	 */
	public Book save(Book newBook);

	/**
	 * to delete book in db
	 * 
	 * @param long id
	 * 
	 * @return List of book
	 */
	public void deleteById(String id);

	/**
	 * to update book in db
	 * 
	 * @param1 book
	 * 
	 * @param2 MultipartFile file
	 * 
	 * @return List of book
	 */
	public void update(Book newBook);

	/**
	 * to find book by id
	 * 
	 * @param String id
	 * @return Optional of book
	 */
	public Optional<Book> findById(String id);

}
