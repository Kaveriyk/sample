package com.nagarro.training.advancejava.Assignment5App2.Controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.training.advancejava.Assignment5App2.Model.Author;
import com.nagarro.training.advancejava.Assignment5App2.Service.authorService;

@SuppressWarnings({ "rawtypes", "unchecked" })
@RestController
public class authorController {

	@Autowired
	private authorService authorrService;

	/**
	 * to get all authors
	 * 
	 * @return response entity
	 */
	@GetMapping("/authors")
	public ResponseEntity<?> all() {
		return new ResponseEntity(authorrService.findAll(), HttpStatus.OK);
	}

	/**
	 * to insert a new author
	 * 
	 * @param newAuthor
	 * @return response entity
	 */
	@PostMapping("/authors/add")
	public ResponseEntity<?> newauthor(@RequestBody Author newAuthor) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("DATA", authorrService.save(newAuthor));
		map.put("Message", "SUCCESSFULLY CREATED");
		return new ResponseEntity(map, HttpStatus.CREATED);
	}

	/**
	 * to update Author
	 * 
	 * @param newAuthor
	 * @param id
	 * @return response entity
	 */
	@PutMapping("/authors/{id}")
	public ResponseEntity<?> updateAuthor(@RequestBody Author newAuthor, @PathVariable int id) {
		HashMap<String, Object> map = new HashMap<>();
		return authorrService.findById(id).map(author -> {
			author.setAuthorName(newAuthor.getAuthorName());
			map.put("DATA", authorrService.save(author));
			map.put("Message", "SUCCESSFULLY UPDATED");
			return new ResponseEntity(map, HttpStatus.OK);
		}).orElseGet(() -> {
			// newAuthor.setId(id);
			// map.put("DATA",authorService.save(newAuthor));
			map.put("Message", "No such ID Exists");
			return new ResponseEntity(map, HttpStatus.BAD_REQUEST);
		});
	}

	/**
	 * to delete author
	 * 
	 * @param id
	 * @return response entity
	 */
	@DeleteMapping("/authors/{id}")
	public ResponseEntity<?> deleteAuthor(@PathVariable int id) {
		HashMap<String, Object> map = new HashMap<>();
		return authorrService.findById(id).map(author -> {
			authorrService.deleteById(id);
			map.put("Message", "SUCCESSFULLY DELETED");
			return new ResponseEntity(map, HttpStatus.OK);
		}).orElseGet(() -> {
			map.put("Message", "No such ID Exists");
			return new ResponseEntity(map, HttpStatus.BAD_REQUEST);
		});
	}

}
