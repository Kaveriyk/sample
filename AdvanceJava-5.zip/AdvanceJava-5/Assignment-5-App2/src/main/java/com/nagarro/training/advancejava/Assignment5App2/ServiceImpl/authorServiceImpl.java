package com.nagarro.training.advancejava.Assignment5App2.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.training.advancejava.Assignment5App2.Model.Author;
import com.nagarro.training.advancejava.Assignment5App2.Repository.authorRepository;
import com.nagarro.training.advancejava.Assignment5App2.Service.authorService;

@Service
public class authorServiceImpl implements authorService {

	@Autowired
	private authorRepository authorRepo;

	/**
	 * to find all the authors in db
	 * 
	 * @return List of author
	 */
	@Override
	public List<Author> findAll() {
		// TODO Auto-generated method stub
		List<Author> authors = (List<Author>) authorRepo.findAll();
		return authors;
	}

	/**
	 * to save new author in db
	 * 
	 * @param newAuthor
	 * @return author
	 */
	@Override
	public Author save(Author newAuthor) {
		return authorRepo.save(newAuthor);
	}

	/**
	 * to find author by id
	 * 
	 * @param id
	 * @return optional of author
	 */
	@Override
	public Optional<Author> findById(int id) {
		return authorRepo.findById(id);
	}

	/**
	 * to delete author by id
	 * 
	 * @param id
	 */
	@Override
	public void deleteById(int id) {
		authorRepo.deleteById(id);
	}

	/**
	 * to update author
	 * 
	 * @param newAuthor
	 */
	@Override
	public void update(Author newAuthor) {
		authorRepo.save(newAuthor);
	}

}
