package com.nagarro.training.advancejava.Assignment5App2.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.training.advancejava.Assignment5App2.Model.Book;

@Repository
@Transactional
public interface bookRepository extends JpaRepository<Book, String> {

}
