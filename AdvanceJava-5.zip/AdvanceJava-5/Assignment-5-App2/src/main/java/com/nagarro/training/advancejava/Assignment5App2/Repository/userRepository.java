package com.nagarro.training.advancejava.Assignment5App2.Repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.training.advancejava.Assignment5App2.Model.User;

@Repository
@Transactional
public interface userRepository extends JpaRepository<User, String> {
	public Optional<User> findByUsername(String username);

}
