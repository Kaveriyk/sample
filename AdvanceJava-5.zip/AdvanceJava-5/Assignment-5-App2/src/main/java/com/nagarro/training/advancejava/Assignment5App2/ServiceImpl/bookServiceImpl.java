package com.nagarro.training.advancejava.Assignment5App2.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.training.advancejava.Assignment5App2.Model.Book;
import com.nagarro.training.advancejava.Assignment5App2.Repository.bookRepository;
import com.nagarro.training.advancejava.Assignment5App2.Service.bookService;

@Service
public class bookServiceImpl implements bookService {

	@Autowired
	private bookRepository bookRepo;

	/**
	 * to find all the books in db
	 * 
	 * @return List of book
	 */
	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		List<Book> authors = (List<Book>) bookRepo.findAll();
		return authors;
	}

	/**
	 * to save book in db
	 * 
	 * @param book
	 * 
	 * @return boolean
	 */
	@Override
	public Book save(Book newBook) {
		return bookRepo.save(newBook);
	}

	/**
	 * to find book by id
	 * 
	 * @param String id
	 * @return Optional of book
	 */
	@Override
	public Optional<Book> findById(String id) {
		return bookRepo.findById(id);
	}

	/**
	 * to delete book in db
	 * 
	 * @param long id
	 * 
	 * @return List of book
	 */
	@Override
	public void deleteById(String id) {
		bookRepo.deleteById(id);
	}

	/**
	 * to update book in db
	 * 
	 * @param1 book
	 * 
	 * @param2 MultipartFile file
	 * 
	 * @return List of book
	 */
	@Override
	public void update(Book newBook) {
		// TODO Auto-generated method stub
		bookRepo.save(newBook);
	}

}
