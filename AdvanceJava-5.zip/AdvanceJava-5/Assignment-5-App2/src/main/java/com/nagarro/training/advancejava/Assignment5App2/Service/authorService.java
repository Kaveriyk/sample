package com.nagarro.training.advancejava.Assignment5App2.Service;

import java.util.List;
import java.util.Optional;

import com.nagarro.training.advancejava.Assignment5App2.Model.Author;

public interface authorService {

	/**
	 * to find all the authors in db
	 * 
	 * @return List of author
	 */
	public List<Author> findAll();

	/**
	 * to save new author in db
	 * 
	 * @param newAuthor
	 * @return author
	 */
	public Author save(Author newAuthor);

	/**
	 * to find author by id
	 * 
	 * @param id
	 * @return optional of author
	 */
	public Optional<Author> findById(int id);

	/**
	 * to delete author by id
	 * 
	 * @param id
	 */
	public void deleteById(int id);

	/**
	 * to update author
	 * 
	 * @param newAuthor
	 */
	public void update(Author newAuthor);

}
