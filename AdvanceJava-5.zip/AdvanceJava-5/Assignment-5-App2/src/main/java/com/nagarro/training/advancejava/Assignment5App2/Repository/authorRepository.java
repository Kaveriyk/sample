package com.nagarro.training.advancejava.Assignment5App2.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.training.advancejava.Assignment5App2.Model.Author;

@Repository
@Transactional
public interface authorRepository extends JpaRepository<Author, Integer> {

}
