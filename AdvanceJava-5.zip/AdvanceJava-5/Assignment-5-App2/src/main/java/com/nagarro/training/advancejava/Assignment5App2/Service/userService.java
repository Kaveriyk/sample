package com.nagarro.training.advancejava.Assignment5App2.Service;

import java.util.Optional;

import com.nagarro.training.advancejava.Assignment5App2.Model.User;

public interface userService {

	/*
	 * to check the credentials
	 * 
	 * @param user login
	 * 
	 * @return boolean
	 */
	public Optional<User> getUser(String username);

}
