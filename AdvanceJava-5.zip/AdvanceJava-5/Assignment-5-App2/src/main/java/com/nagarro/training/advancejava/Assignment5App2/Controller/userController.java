package com.nagarro.training.advancejava.Assignment5App2.Controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.training.advancejava.Assignment5App2.Service.userService;

@RestController
public class userController {

	@Autowired
	private userService userrService;

	/**
	 * to find user by username
	 * 
	 * @param username
	 * @return response entity
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/login/{username}")
	public ResponseEntity<?> findbyUsername(@PathVariable String username) {
		HashMap<String, Object> map = new HashMap<>();
		return userrService.getUser(username).map(book -> {
			// authorService.deleteById(id);
			// map.put("Message", "SUCCESSFULLY DELETED");
			return new ResponseEntity(book, HttpStatus.OK);
		}).orElseGet(() -> {
			map.put("Message", "No such User Exists");
			return new ResponseEntity(map, HttpStatus.OK);
		});
	}

}
