package com.nagarro.training.advancejava.Assignment5App2.ServiceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.training.advancejava.Assignment5App2.Model.User;
import com.nagarro.training.advancejava.Assignment5App2.Repository.userRepository;
import com.nagarro.training.advancejava.Assignment5App2.Service.userService;

@Service
public class userServiceImpl implements userService {
	@Autowired
	private userRepository userRepo;

	/*
	 * to check the credentials
	 * 
	 * @param user login
	 * 
	 * @return boolean
	 */
	@Override
	public Optional<User> getUser(String username) {
		return userRepo.findByUsername(username);
	}

}
