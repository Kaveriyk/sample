package com.nagarro.training.advancejava.Assignment5App2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment5App2Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment5App2Application.class, args);
	}

}
