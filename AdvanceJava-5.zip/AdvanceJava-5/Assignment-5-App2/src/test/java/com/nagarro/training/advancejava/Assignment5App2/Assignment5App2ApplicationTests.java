package com.nagarro.training.advancejava.Assignment5App2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment5App2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
